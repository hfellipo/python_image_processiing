# image_processing

Description.
The package image_processing is used to:
    Processing:
        Histogram matching
        Structural similarity



## Installation
Use the package manager pip to install image_processing

pip install image_processing

## Usage
    from package_name import file1_name
    file1_name.my_function()
    
## Author
Herme Fellipo

## License
xxxx-xxxx